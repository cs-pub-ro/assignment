import queue
import copy

from dfa import DFA


def epsilon_closure(nfa, state):
    """Get epsilon closure of a state"""
    def epsilon_closure_aux(nfa, state, closure):
        for next_state in nfa.delta.get((state, ""), set()):
            if next_state not in closure:
                closure |= {next_state}
                closure |= epsilon_closure_aux(nfa, next_state, closure)

        return closure

    return epsilon_closure_aux(nfa, state, {state})


def new_states(count, *nfas):
    state = 0
    for nfa in nfas:
        m = max(nfa.states)
        if m >= state:
            state = m + 1

    return list(range(state, state + count + 1))


def remove_word_transitions(old_nfa):
    """Normalize an NFA to have no transitions on words with length > 1"""
    nfa = copy.deepcopy(old_nfa)

    for ((crt, word), nxt) in old_nfa.delta.items():
        if len(word) <= 1:
            continue

        extra = new_states(len(word) - 1, nfa)
        del nfa.delta[(crt, word)]
        nfa.delta[(crt, word[0])] = {extra[0]}
        for i, st in enumerate(extra[:-1]):
            nfa.delta[(extra[i], word[i + 1])] = {extra[i + 1]}

        nfa.delta[(extra[-1], word[-1])] = nxt

    return nfa


def nfa_to_dfa(nfa):
    """Subset construction"""
    def set_to_int(s, converted={}):
        fs = frozenset(s)
        if fs not in converted:
            converted[fs] = len(converted)

        return converted[fs]

    nfa = remove_word_transitions(nfa)
    init_ec = epsilon_closure(nfa, nfa.start_state)
    start_state = set_to_int(init_ec)
    states = {start_state}
    alphabet = nfa.alphabet
    final_states = set()
    delta = {}
    frontier = queue.Queue()
    frontier.put(init_ec)
    visited = set()

    # special case for start_state
    for nstate in init_ec:
        if nstate in nfa.final_states:
            final_states.add(start_state)
            break

    while not frontier.empty():
        crt_dstate = frontier.get()
        crt = set_to_int(crt_dstate)
        visited.add(crt)
        for symbol in alphabet:
            next_dstate = set()
            for nstate in crt_dstate:
                next_nstates = nfa.delta.get((nstate, symbol), set())
                next_nstates |= nfa.delta.get((nstate, "."), set())
                for nns in next_nstates:
                    next_dstate |= epsilon_closure(nfa, nns)

            nxt = set_to_int(next_dstate)

            delta[(crt, symbol)] = nxt
            if nxt not in visited:
                for nstate in next_dstate:
                    if nstate in nfa.final_states:
                        final_states.add(nxt)
                        break

                states.add(nxt)
                frontier.put(next_dstate)

    return DFA(alphabet, states, start_state, final_states, delta)
