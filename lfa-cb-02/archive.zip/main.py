#!/usr/bin/env python
import sys

import nfa
import nfa_to_dfa


def parse_nfa(text):
    """Ad-hoc parsing of an NFA.

    text must have the following format:

    <number of states>
    <final state 1> <final state 2> ... <final state n>
    <current state> <simbol> <next state 1> <next state 2> ... <next state m1>
    <current state> <simbol> <next state 1> <next state 2> ... <next state m2>
    ...
    <current state> <simbol> <next state 1> <next state 2> ... <next state mi>

    Where <simbol> is either a single character standing for a symbol in the
    alphabet, or the string "eps" representing the empty string

    """
    def build_delta(transitions):
        delta = {}
        alphabet = set()
        for transition in transitions:
            elems = transition.split()
            if elems[1] == "eps":
                elems[1] = ""
            else:
                alphabet.add(elems[1])

            delta[(int(elems[0]), elems[1])] = set(int(s) for s in elems[2:])

        return delta, alphabet

    lines = text.splitlines()
    final_states = set(int(s) for s in lines[1].split())
    delta, alphabet = build_delta(lines[2:])
    states = list(range(0, int(lines[0])))

    return nfa.NFA(alphabet, states, 0, final_states, delta)


def serialize_dfa(dfa):
    s = ""
    s += str(len(dfa.states)) + "\n"
    s += " ".join((str(s) for s in dfa.final_states)) + "\n"
    for (state, ch), nstate in dfa.delta.items():
        s += " ".join([str(state), ch, str(nstate)]) + "\n"

    return s


def conv_nfa(text):
    nfa = parse_nfa(text)
    dfa = nfa_to_dfa.nfa_to_dfa(nfa)
    return serialize_dfa(dfa)


if __name__ == "__main__":
    with open(sys.argv[1], "r") as fin:
        text = fin.read()

    s = conv_nfa(text)

    with open(sys.argv[2], "w") as fout:
        fout.write(s)
