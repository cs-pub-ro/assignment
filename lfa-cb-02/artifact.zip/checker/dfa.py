from graphviz import Digraph


class DFA(object):
    """Model a Nondeterministic Finite Automaton

    The automaton contains the following:

        - "alphabet": a set of symbols
        - "states": set of non-negative integers
        - "start_state": a member of "states"
        - "final_states": a subset of "states"
        - "delta": a dictionary from configurations to states
                {(state, symbol): state}
                where "state" is a member of "states" and "symbol" is a member
                of "alphabet"

    """

    def __init__(self, alphabet, states, start_state, final_states, delta):
        """See class docstring"""
        assert start_state in states
        assert final_states.issubset(states)
        for symbol in "()*|":
            assert symbol not in alphabet

        self.alphabet = alphabet
        self.states = states
        self.start_state = start_state
        self.final_states = final_states
        self.delta = delta
        self.sink_state = None

    def get_sink_state(self):
        """Get the sink state if any

        If the DFA does not have a sink state, None will be returned.
        The sink state is computed the first time this function is called.

        Note that this is only meaningful for minimized DFAs!

        """
        if self.sink_state is not None:
            return self.sink_state

        for state in self.states:
            if state in self.final_states:
                continue

            is_sink = True
            for symbol in self.alphabet:
                if self.delta[(state, symbol)] != state:
                    is_sink = False

            if is_sink:
                self.sink_state = state
                return self.sink_state

        return None

    def accept(self, string):
        """Check if a string is in the DFA's language"""
        current_state = self.start_state
        sink_state = self.get_sink_state()
        for symbol in string:
            current_state = self.delta.get((current_state, symbol), sink_state)
            if current_state == sink_state:  # early bailout
                return False

        return current_state in self.final_states

    def to_graphviz(self):
        def get_edges(delta):
            edges = {}
            for (prev_state, symbol), next_state in delta.items():
                edge = (prev_state, next_state)
                if edge not in edges:
                    edges[edge] = set()

                edges[edge].add(symbol)

            return edges

        def collate_symbols(edge_symbols):
            collated = []
            i = 0
            edge_symbols = sorted(edge_symbols)
            while i < len(edge_symbols):
                range_start = i
                while i + 1 < len(edge_symbols) and \
                        ord(edge_symbols[i + 1]) == ord(edge_symbols[i]) + 1:
                    i += 1

                dist = i - range_start
                if dist >= 2:
                    label = "{}-{}".format(edge_symbols[range_start],
                                           edge_symbols[i])
                    collated.append(label)
                else:
                    collated.append(str(edge_symbols[range_start]))
                    if dist == 1:
                        collated.append(str(edge_symbols[range_start + 1]))
                        i += 1

                i += 1

            return ",".join(collated)

        dot = Digraph()
        dot.graph_attr["rankdir"] = "LR"

        # This is here to nicely mark the starting state.
        dot.node("_", shape="point")
        dot.edge("_", str(self.start_state))

        for state in self.states:
            shape = "doublecircle" if state in self.final_states else "circle"
            dot.node(str(state), shape=shape)

        edges = get_edges(self.delta)

        edges = {k: collate_symbols(v) for k, v in edges.items()}
        for (prev_state, next_state), label in edges.items():
            dot.edge(str(prev_state), str(next_state), label=label)

        return dot


def parse_dfa(text):
    """Ad-hoc parsing of an dFA.

    text must have the following format:

    <number of states>
    <final state 1> <final state 2> ... <final state n>
    <current state> <simbol> <next state>
    <current state> <simbol> <next state>
    ...
    <current state> <simbol> <next state>

    """
    def build_delta(transitions):
        delta = {}
        alphabet = set()
        for transition in transitions:
            elems = transition.split(" ")
            delta[(int(elems[0]), elems[1])] = int(elems[2])
            alphabet.add(elems[1])

        return delta, alphabet

    lines = text.splitlines()
    final_states = set(int(s) for s in lines[1].split(" "))
    delta, alphabet = build_delta(lines[2:])
    states = set(range(0, int(lines[0])))

    return DFA(alphabet, states, 0, final_states, delta)
