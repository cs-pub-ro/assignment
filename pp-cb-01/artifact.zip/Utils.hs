module Utils where

{--
    Splitting function extracted from pdmatei github.
    Takes a delimitator character and a string and returns a list of strings.
--}
splitBy :: Char -> String -> [String]
splitBy c = foldr op [[]]
    where op x (y:ys)
            | x /= c = (x:y):ys
            | otherwise = []:(y:ys)

-- Converts String to Float.
string_to_float :: String -> Float 
string_to_float str = if length str == 0 then 0 else read str :: Float

-- Converts a list of Strings to their sum as Floats.
string_to_float_sum :: [String] -> Float
string_to_float_sum list = foldr (\field acc -> acc + (string_to_float field)) 0 list

string_to_float_diff :: String -> String -> Float
string_to_float_diff str1 str2 = (string_to_float str1)-(string_to_float str2)

-- Converts Int to Float.
int_to_float :: Int -> Float
int_to_float x = fromIntegral x :: Float

-- Comparation function for 2 table rows, based on their last column, which must be
-- a string containing a Float value.
cmp_entries row1 row2
	| string_to_float (last row1) == string_to_float (last row2) && (head row1) < (head row2) = LT
    | string_to_float (last row1) < string_to_float (last row2) = LT 
    | otherwise = GT