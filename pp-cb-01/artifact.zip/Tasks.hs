module Tasks where

import Data.List
import Data.String

import Dataset
import Utils

type CVS = String
type Column = String
type Entry = [Column]
type Table = [Entry]

-- Reads a CVS-format string and returns the contained table.
read_cvs :: CVS -> Table
read_cvs cvs = (init $ map (splitBy ',') $ splitBy '\n' cvs)

-- Writes a table to a string in CVS-format.
write_cvs :: Table -> CVS
write_cvs table =
    foldr (\line acc -> (intercalate "," line) ++ "\n" ++ acc) "" table

-- Task 1
{-
    Create Table for Exam Grades. On every row, replace columns Q1,..,Q6,Scris with column
    Punctaj Exam. The value for this firls is (Q1+..Q6)*3/12 + Scris.
-}
exam_grades_schema = ["Nume", "Punctaj Exam"]

compute_exam_grades :: Table -> Table
compute_exam_grades (schema:rows) = exam_grades_schema:(map compute_exam_grade rows)
    where
        compute_exam_grade :: Entry -> Entry
        compute_exam_grade (name:exam_points) =
            [name, show ((interview_grade (init exam_points)) + (read (last exam_points) :: Float))]        

-- Applies formula for computing the oral exam grade, based on the marks receives on those 6 questions. 
interview_grade :: Entry -> Float
interview_grade points = (string_to_float_sum points) * 3 / 12

-- Task 2
get_passed_students_num :: Table -> Int
get_passed_students_num exam_grades =
    foldr check_exam_status 0 (tail (compute_exam_grades exam_grades))
    where
        check_exam_status :: Entry -> Int -> Int
        check_exam_status [_, grade_str] acc
            | (read grade_str :: Float) >= 2.5 = acc + 1
            | otherwise = acc

get_passed_students_percentage :: Table -> Float
get_passed_students_percentage exam_grades =
    (int_to_float $ get_passed_students_num exam_grades)
        / (int_to_float $ length (tail (compute_exam_grades exam_grades)))

get_exam_avg :: Table -> Float
get_exam_avg exam_grades = get_avg $ tail (compute_exam_grades exam_grades)
    where
        get_avg :: Table -> Float
        get_avg grades = (foldr (\[name, grade] acc -> acc+(read grade :: Float)) 0.0 grades)
            / (int_to_float $ length grades)

-- get_passed_hw_num :: Table -> Int
get_passed_hw_num hw_grades = foldr aux 0 (tail hw_grades)
    where
        aux [name, _, t1, t2, t3, _, _, _, _] acc
            | (string_to_float_sum [t1,t2,t3]) >= 1.5 = acc + 1
            | otherwise = acc

-- Task 3
get_avg_responses_per_qs :: Table -> Table
get_avg_responses_per_qs (schema:rows) = [schema_r, (map show (avg_per_row (init $ tail $ transpose rows)))]
    where
        schema_r = ["Q1", "Q2", "Q3", "Q4", "Q5", "Q6"]
        avg_per_row :: Table -> [Float]
        avg_per_row [] = []
        avg_per_row (row:rows) = ((string_to_float_sum row) / (int_to_float $ length row)):(avg_per_row rows)

-- Task 4
exam_summary_Schema = ["Q", "0", "1", "2"]

get_exam_summary :: Table -> Table
get_exam_summary exam_grades = exam_summary_Schema:(process_questions $ init $ tail $ transpose exam_grades)
    where
        process_questions :: [[String]] -> [[String]]
        process_questions [] = []
        process_questions ((name:values):rows) =
            [name, find_val 0 "0" values, find_val 0 "1" values, find_val 0 "2" values]:(process_questions rows)

        -- Counts number of appearances of value in a list and stores it in accumulator, then returns
        -- the accumulator converted to a String.
        find_val :: Integer -> String -> [String] -> String
        find_val acc _ [] = show acc
        find_val acc val (x:xs) = if x == val then find_val (acc+1) val xs else find_val acc val xs

-- Task 5
-- EX. 4 - Ranking of students based on their final grade.
get_ranking :: Table -> Table
get_ranking exam_grades =
    sort_entries (compute_exam_grades exam_grades)
    where
        sort_entries (schema:rows) = schema:(sortBy cmp_entries rows)

-- Task 6
exam_diff_schema = ["Nume", "Punctaj interviu", "Punctaj scris", "Diferenta"]

get_exam_diff_table :: Table -> Table
get_exam_diff_table (schema:rows) = exam_diff_schema:(sortBy cmp_entries $ compute_diff $ process_exam rows)
    where
        -- From [Nume,Q1,..,Q6,Ex. Scris] Table => [Nume, Ex. Oral, Ex. Scris] Table
        process_exam :: Table -> Table
        process_exam rows = map (\(name:points) -> [name, show $ interview_grade $ init points, last points]) rows
        -- Part 2 of Idea. Replace Ex.Oral,Ex.Scris with abs(Ex.Scris-Ex.Oral)
        compute_diff :: Table -> Table
        compute_diff rows = map
            (\[name, oral, written] -> [name, oral, written, show $ abs $ string_to_float_diff oral written]) rows
