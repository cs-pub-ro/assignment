#!/usr/bin/env python3
import os
import subprocess
import sys
from subprocess import PIPE
import traceback
sys.path.append("checker")



POINTS_PER_TEST_NFA = 10
POINTS_PER_TEST_DFA = 5
SRCFILE = "main.py"
TESTDIR = "tests"
TEST_TIMEOUT = 16  # seconds

class DFA(object):
    def __init__(self, alphabet, states, start_state, final_states, delta):
        assert start_state in states, "Start state not in states"
        assert final_states.issubset(states), \
            "Final states ({}) not subset of states ({})".format(final_states,
                                                                 states)
        for symbol in "()*|":
            assert symbol not in alphabet

        self.alphabet = alphabet
        self.states = states
        self.start_state = start_state
        self.final_states = final_states
        self.delta = delta
        self.sink_state = None

    def get_sink_state(self):
        if self.sink_state is not None:
            return self.sink_state

        for state in self.states:
            if state in self.final_states:
                continue

            is_sink = True
            for symbol in self.alphabet:
                if self.delta[(state, symbol)] != state:
                    is_sink = False

            if is_sink:
                self.sink_state = state
                return self.sink_state

        return None

    def accept(self, string):
        """Check if a string is in the DFA's language"""
        current_state = self.start_state
        sink_state = self.get_sink_state()
        for symbol in string:
            current_state = self.delta.get((current_state, symbol), sink_state)
            if current_state == sink_state:  # early bailout
                return False

        return current_state in self.final_states


def parse_dfa(text):
    """Ad-hoc parsing of an dFA.

    text must have the following format:

    <number of states>
    <final state 1> <final state 2> ... <final state n>
    <current state> <simbol> <next state>
    <current state> <simbol> <next state>
    ...
    <current state> <simbol> <next state>

    """
    def build_delta(transitions):
        delta = {}
        alphabet = set()
        states = set()
        for transition in transitions:
            elems = transition.split()
            delta[(int(elems[0]), elems[1])] = int(elems[2])
            states.add(int(elems[0]))
            states.add(int(elems[2]))
            alphabet.add(elems[1])

        return delta, alphabet, states

    def normalize(states, final_states, delta):
        translate = {name: index for index, name in enumerate(states)}
        new_delta = {(translate[c], s): translate[n] for (c, s), n in
                     delta.items()}
        new_finals = {translate[s] for s in final_states}
        new_states = {translate[s] for s in states}

        return new_states, new_finals, new_delta

    lines = text.splitlines()
    delta, alphabet, states = build_delta(lines[2:])
    final_states = set(int(s) for s in lines[1].split())
    states, final_states, delta = normalize(states, final_states, delta)

    return DFA(alphabet, states, 0, final_states, delta)

class NFA(object):
    def __init__(self, alphabet, states, start_state, final_states, delta):
        assert start_state in states
        assert final_states.issubset(states)
        for symbol in "()*|":
            assert symbol not in alphabet

        self.alphabet = alphabet
        self.states = states
        self.start_state = start_state
        self.final_states = final_states
        self.delta = delta

def parse_nfa(text):
    def build_delta(transitions):
        delta = {}
        alphabet = set()
        for transition in transitions:
            elems = transition.split()
            if elems[1] == "eps":
                elems[1] = ""
            else:
                alphabet.add(elems[1])

            delta[(int(elems[0]), elems[1])] = set(int(s) for s in elems[2:])

        return delta, alphabet

    lines = text.splitlines()
    final_states = set(int(s) for s in lines[1].split())
    delta, alphabet = build_delta(lines[2:])
    states = list(range(0, int(lines[0])))

    return NFA(alphabet, states, 0, final_states, delta)

import queue
import copy


def epsilon_closure(nfa, state):
    """Get epsilon closure of a state"""
    def epsilon_closure_aux(nfa, state, closure):
        for next_state in nfa.delta.get((state, ""), set()):
            if next_state not in closure:
                closure |= {next_state}
                closure |= epsilon_closure_aux(nfa, next_state, closure)

        return closure

    return epsilon_closure_aux(nfa, state, {state})


def new_states(count, *nfas):
    state = 0
    for nfa in nfas:
        m = max(nfa.states)
        if m >= state:
            state = m + 1

    return list(range(state, state + count + 1))


def remove_word_transitions(old_nfa):
    """Normalize an NFA to have no transitions on words with length > 1"""
    nfa = copy.deepcopy(old_nfa)

    for ((crt, word), nxt) in old_nfa.delta.items():
        if len(word) <= 1:
            continue

        extra = new_states(len(word) - 1, nfa)
        del nfa.delta[(crt, word)]
        nfa.delta[(crt, word[0])] = {extra[0]}
        for i, st in enumerate(extra[:-1]):
            nfa.delta[(extra[i], word[i + 1])] = {extra[i + 1]}

        nfa.delta[(extra[-1], word[-1])] = nxt

    return nfa


def nfa_to_dfa(nfa):
    def set_to_int(s, converted={}):
        fs = frozenset(s)
        if fs not in converted:
            converted[fs] = len(converted)

        return converted[fs]

    nfa = remove_word_transitions(nfa)
    init_ec = epsilon_closure(nfa, nfa.start_state)
    start_state = set_to_int(init_ec)
    states = {start_state}
    alphabet = nfa.alphabet
    final_states = set()
    delta = {}
    frontier = queue.Queue()
    frontier.put(init_ec)
    visited = set()

    # special case for start_state
    for nstate in init_ec:
        if nstate in nfa.final_states:
            final_states.add(start_state)
            break

    while not frontier.empty():
        crt_dstate = frontier.get()
        crt = set_to_int(crt_dstate)
        visited.add(crt)
        for symbol in alphabet:
            next_dstate = set()
            for nstate in crt_dstate:
                next_nstates = nfa.delta.get((nstate, symbol), set())
                next_nstates |= nfa.delta.get((nstate, "."), set())
                for nns in next_nstates:
                    next_dstate |= epsilon_closure(nfa, nns)

            nxt = set_to_int(next_dstate)

            delta[(crt, symbol)] = nxt
            if nxt not in visited:
                for nstate in next_dstate:
                    if nstate in nfa.final_states:
                        final_states.add(nxt)
                        break

                states.add(nxt)
                frontier.put(next_dstate)

    return DFA(alphabet, states, start_state, final_states, delta)


def symmetric_difference(lhs, rhs):
    def new_state_name(ls, rs):
        return ls * len(rhs.states) + rs

    alphabet = lhs.alphabet
    states = set(range(len(lhs.states) * len(rhs.states)))

    final_states = set()
    for ls in lhs.states:
        for rs in rhs.states:
            ns = new_state_name(ls, rs)
            if (ls in lhs.final_states) and (rs not in rhs.final_states) or \
                    (ls not in lhs.final_states) and (rs in rhs.final_states):
                final_states.add(ns)

    start_state = new_state_name(lhs.start_state, rhs.start_state)

    delta = {}
    for ls in lhs.states:
        for rs in rhs.states:
            for ch in alphabet:
                ns = new_state_name(ls, rs)
                nns = new_state_name(lhs.delta[(ls, ch)], rhs.delta[(rs, ch)])
                delta[(ns, ch)] = nns

    return DFA(alphabet, states, start_state, final_states, delta)


def empty_language(a):
    visited = [False for state in a.states]

    def dfs_reach_final(state):
        visited[state] = True
        for ch in a.alphabet:
            nstate = a.delta[(state, ch)]
            if nstate in a.final_states:
                return True

            if not visited[nstate]:
                if dfs_reach_final(nstate):
                    return True

        return False

    return not dfs_reach_final(a.start_state)


def language_eq(lhs, rhs):
    da = symmetric_difference(lhs, rhs)
    return empty_language(da)



def equivalence(out_nfa, ref_nfa):
    out_dfa = nfa_to_dfa(out_nfa)
    ref_dfa = nfa_to_dfa(ref_nfa)

    return language_eq(out_dfa, ref_dfa)




def run_test_nfa(test, outfile, reffile):
    try:
        with open(reffile, "r") as fin:
            ref_text_nfa = fin.read()
    except FileNotFoundError:
        print("No ref file for test {}".format(test), file=sys.stderr)
        return False

    try:
        with open(outfile, "r") as fin:
            out_text_nfa = fin.read()
    except FileNotFoundError:
        print("No out file for test {}".format(test), file=sys.stderr)
        return False

    try:
        out_nfa = parse_nfa(out_text_nfa)
        ref_nfa = parse_nfa(ref_text_nfa)

        return equivalence(out_nfa, ref_nfa)
    except AssertionError as e:
        print("Assertion error:", file=sys.stderr)
        print(e, file=sys.stderr)
        return False
    except Exception as e:
        print("Exception raised while checking equivalence:", file=sys.stderr)
        traceback.print_exc(e)
        return False

def run_test_dfa(test, outfile, reffile):
    try:
        with open(reffile, "r") as fin:
            ref_text_dfa = fin.read()
    except FileNotFoundError:
        print("No ref file for test {}".format(test), file=sys.stderr)
        return False

    try:
        with open(outfile, "r") as fin:
            out_text_dfa = fin.read()
    except FileNotFoundError:
        print("No out file for test {}".format(test), file=sys.stderr)
        print("Output of current run:", file=sys.stderr)
        print(cp.stdout.decode("utf-8"), file=sys.stderr)
        return False

    try:
        out_dfa = parse_dfa(out_text_dfa)
        ref_dfa = parse_dfa(ref_text_dfa)

        return language_eq(out_dfa, ref_dfa)
    except AssertionError as e:
        print("Assertion error:", file=sys.stderr)
        print(e, file=sys.stderr)
        return False
    except Exception as e:
        print("Exception raised while checking equivalence:", file=sys.stderr)
        traceback.print_exc(e)
        return False


def run_test(test):
    # Ensure out directory exists
    test_out = os.path.join(TESTDIR, "out")
    os.makedirs(test_out, exist_ok=True)
    test_out1 = os.path.join(TESTDIR, "out/nfa")
    test_out2 = os.path.join(TESTDIR, "out/dfa")
    os.makedirs(test_out1, exist_ok=True)
    os.makedirs(test_out2, exist_ok=True)

    infile = os.path.join(TESTDIR, "in", test)
    outfile1 = os.path.join(test_out1, test)
    outfile2 = os.path.join(test_out2, test)
    reffile1 = os.path.join(TESTDIR, "ref/nfa", test)
    reffile2 = os.path.join(TESTDIR, "ref/dfa", test)

    print(infile, outfile1, outfile2)


    cmd = "python3 '{}' '{}' '{}' '{}'".format(SRCFILE, infile, outfile1, outfile2)
    timeout_cmd = "timeout -k {0} {0} {1} 2>&1".format(TEST_TIMEOUT, cmd)
    cp = subprocess.run(timeout_cmd, shell=True, stdout=PIPE, stderr=PIPE)
    if cp.returncode == 124:
        print("TIMEOUT on test {}".format(test), file=sys.stderr)
        return None

    return (run_test_nfa(test, outfile1, reffile1), run_test_dfa(test, outfile2, reffile2))


if __name__ == "__main__":
    if not (os.path.isfile(SRCFILE) and os.access(SRCFILE, os.R_OK)):
        sys.stderr.write("{} unavailable or unreadable!\n".format(SRCFILE))
        sys.exit(1)

    tests = os.listdir(os.path.join(TESTDIR, "in"))
    nr_tests = len(tests)
    total = 0
    max_points = nr_tests * (POINTS_PER_TEST_NFA + POINTS_PER_TEST_DFA)

    header = " Running tests: "
    # This number is computed by summing the numbers in {} and the count of
    # characters outside of {} in...
    print("{:=^73}".format(header))
    print("{} {: <25} {: >20} {: >8} {: >8}\n".format("TEST #  ", "NAME", "",
                                                      "STATUS", "POINTS"))
    results = {
        'NFA': {},
        'DFA': {}
    }
    for i, test in enumerate(tests):
        passed = run_test(test)
        if passed is not None:
            passed1, passed2 = passed
        else:
            passed1, passed2 = (False, False)

        results['NFA'][i] = (test, passed1)
        results['DFA'][i] = (test, passed2)


    print("TESTING TASK 1 - ER -> NFA\n")
    for i in results['NFA'].keys():
        (test, passed1) = results['NFA'][i]
        crt_points = POINTS_PER_TEST_NFA if passed1 else 0
        total += crt_points
        str_status = "PASSED" if passed1 else "FAILED"
        str_points = "[{}/{}]".format(crt_points, POINTS_PER_TEST_NFA)
        # ... this print
        print("{: >6} - {: <25} {:.>20} {: >8} {: >8}".format(i + 1, test, "",
                                                              str_status,
                                                              str_points))
    print("\n\nTESTING TASK 2 - NFA -> DFA\n")
    for i in results['NFA'].keys():
        (test, passed2) = results['DFA'][i]
        crt_points = POINTS_PER_TEST_DFA if passed2 else 0
        total += crt_points
        str_status = "PASSED" if passed2 else "FAILED"
        str_points = "[{}/{}]".format(crt_points, POINTS_PER_TEST_DFA)
        # ... this print
        print("{: >6} - {: <25} {:.>20} {: >8} {: >8}".format(i + 1, test, "",
                                                              str_status,
                                                              str_points))

    print("\nTOTAL: {}/{}\n".format(total, max_points))
