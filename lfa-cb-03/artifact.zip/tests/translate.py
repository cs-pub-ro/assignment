


with open("correct") as fin:
    states = []
    init = None
    final = []
    transitions = []

    lane = fin.readline()[:-1]
    if lane == "#states":
        lane = fin.readline()[:-1]
        while lane != "#initial":
            states.append(lane)
            lane = fin.readline()[:-1]

    lane = fin.readline()[:-1]
    init = lane

    lane = fin.readline()[:-1]
    if lane == "#accepting":
        lane = fin.readline()[:-1]
        while lane != "#alphabet":
            final.append(lane)
            lane = fin.readline()[:-1]

    if lane == "#alphabet":
        while lane != "#transitions":
            lane = fin.readline()[:-1]
            continue

    if lane == "#transitions":
        lane = fin.readline()[:-1]
        while lane != "":

            lane = lane.split(":")
            start = lane[0]
            lane = lane[1]
            lane = lane.split(">")
            symbol = lane[0]
            next = lane[1]

            if symbol == "$":
                symbol = "eps"

            transitions.append((start, symbol, " ".join(next.split(","))))
            lane = fin.readline()[:-1]

    print(len(states))
    print(" ".join(final))
    for start, symbol, next in transitions:
        print(start, symbol, next)
