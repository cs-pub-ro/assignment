with open("random_file10.in") as fin:
    er = fin.readline()
    new_er = "+"
    for i in range(len(er)-1):
        if er[i] == "*" and new_er[-1] == "*":
            continue
        new_er += er[i]

    print(new_er[1:].replace("|", "+"))
